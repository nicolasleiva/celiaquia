import type { AnalysisResult } from '../types';

// The API key provided by the user. In a production app, this should be handled via environment variables.
const GROQ_API_KEY = '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';
const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const MODEL = 'meta-llama/llama-4-scout-17b-16e-instruct';

export const analyzeProductImage = async (
  imageDataUrl: string
): Promise<AnalysisResult> => {
  const systemPrompt = `Eres un asistente experto de IA especializado en seguridad alimentaria para celíacos. Tu tarea es determinar si un producto es adecuado para una persona con enfermedad celíaca basándote en una imagen del producto, sus ingredientes o su empaque. Analiza la imagen proporcionada y responde ÚNICAMENTE en el siguiente formato JSON:
{
  "suitable": boolean,
  "reason": "Una explicación breve y fácil de entender de tu decisión en español. Si el producto es apto, confírmalo. Si no lo es, explica por qué (ej: 'Contiene harina de trigo'). Si no puedes determinarlo con certeza por la imagen, explícalo."
}`;

  const userPromptContent = [
      {
        type: 'text',
        text: 'Analiza la imagen de este producto y dime si es apto para un celíaco. Revisa cuidadosamente los ingredientes si son visibles.',
      },
      {
        type: 'image_url',
        image_url: {
          url: imageDataUrl,
        },
      },
    ];

  try {
    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPromptContent },
        ],
        temperature: 0.1,
        max_tokens: 1024,
        top_p: 1,
        stream: false,
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('Groq API Error:', errorData);
      if (errorData.error?.message.includes('vision')) {
        throw new Error('El modelo actual no parece soportar análisis de imágenes. Por favor, contacte al desarrollador.');
      }
      throw new Error(`Error de la API: ${errorData.error?.message || response.statusText}`);
    }

    const data = await response.json();
    const content = data.choices[0]?.message?.content;

    if (!content) {
      throw new Error('Respuesta inesperada de la API.');
    }
    
    // Sometimes the JSON can be inside a markdown block
    const cleanedContent = content.replace(/```json\n?|```/g, '').trim();
    const parsedResult: AnalysisResult = JSON.parse(cleanedContent);

    return parsedResult;
  } catch (error) {
    console.error('Error analyzing product:', error);
    if (error instanceof Error) {
        throw new Error(`No se pudo analizar el producto. ${error.message}`);
    }
    throw new Error('No se pudo analizar el producto debido a un error desconocido.');
  }
};