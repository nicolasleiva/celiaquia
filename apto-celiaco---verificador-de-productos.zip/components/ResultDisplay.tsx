
import React from 'react';
import type { AnalysisResult } from '../types';

interface ResultDisplayProps {
  result: AnalysisResult;
}

const CheckCircleIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const XCircleIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result }) => {
  const isSuitable = result.suitable;
  const cardClasses = isSuitable
    ? 'bg-green-900/50 border-green-500'
    : 'bg-red-900/50 border-red-500';
  const textClasses = isSuitable ? 'text-green-300' : 'text-red-300';
  const icon = isSuitable ? <CheckCircleIcon /> : <XCircleIcon />;
  const title = isSuitable ? 'Producto Apto' : 'Producto No Apto';

  return (
    <div className={`w-full max-w-2xl mt-8 p-6 border-2 rounded-2xl shadow-lg backdrop-blur-sm ${cardClasses} transition-all duration-500 ease-in-out`}>
      <div className="flex flex-col items-center text-center">
        <div className={`${textClasses} mb-4`}>{icon}</div>
        <h2 className={`text-3xl font-bold mb-3 ${isSuitable ? 'text-green-200' : 'text-red-200'}`}>{title}</h2>
        <p className="text-gray-300 text-lg">{result.reason}</p>
      </div>
    </div>
  );
};

export default ResultDisplay;
